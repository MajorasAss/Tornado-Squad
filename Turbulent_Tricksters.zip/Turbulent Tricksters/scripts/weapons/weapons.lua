local mod = modApi:getCurrentMod()
local path = mod.scriptPath
require(path .."weapons/Rotor")